print("Intro to swift\n")
print("LESSON 1")
print("The Basics\n")

let name = "Akrom"
let surname = "Kassymov"
let height = "184"
let weight = "72"
let age = "19"
print("Student name: \(name)\nSurname: \(surname)")
print("Age of the student: \(age) years old")
print("Weight of the student: \(weight) kg \nHeight of the student: \(height) cm")


print("\n\n\nLESSON 2")
print("Basic types\n")
let minValue = UInt8.min
let maxValue = UInt8.max
print("Unsigned int minimum value: \(minValue)")
print("Unsigned int maximum value: \(maxValue)")
let a : Float = 5.2
let b = 5.3
let c = 5
let d = Int(a) + Int(b) + c
let e = a + Float(b) + Float(c)
let f = Double(a) + b + Double(c)
print(d)
print(e)
print(f)
if Double(d) > f {
  print("D more than F")
}
else if Double(d) == f {
  print("F equal to D")
}
else{
  print("F more than D")
}
var temp = Int(maxValue) + c
print (temp)


print("\n\n\nLESSON 3")
print("TUPLES\n")
var maxcount = (squat : 40, pushup : 30, pullup : 20)
var(squat, pushup, pullup) = maxcount
print(maxcount)
print("Maximum pullups:\(maxcount.pullup)")
print("Maximum squats:\(maxcount.0)")
print("Maximum pushups:\(maxcount.pushup)")
var myfriend = (squat:35, pushup:25, pullup:45)
var temporary:Int = myfriend.squat
myfriend.squat = maxcount.0
maxcount.0 = temporary
print(maxcount.0, myfriend.0)


print("\n\n\nLESSON 4")
print("Optionals\n")
var apple : Int? = 5

if var number = apple{
  number += 1
  print (number)
  apple = nil
  if var number = apple{
    number += 1
    print (number)
  } else {
    print("No apples")
  }
} else {
  print("No apples")
}

let const1 = 12
let const2 = 13
let const3 = 14
let const4 = "15"
if Int(const4) != nil {              //forced unwrapping
  let g = Int(const4)
  let total = const1 + const2 + const3 + g!
  print(total)
}
let const5 = "16"
if Int(const4) != nil{
  let h = Int(const5)
  let total = const1 + const2 + const3 + h!
  print(total)
}

var serveranswer : (statuscode : Int, message : String?, errormessage : String? )
serveranswer.0 = 105
if 200 <= serveranswer.statuscode {
  if serveranswer.0 > 300 {
    serveranswer.message = "true"
    serveranswer.errormessage = nil
    print(serveranswer)
  }
} else{
  serveranswer.errormessage = "true"
  serveranswer.message = nil
  print(serveranswer)
}


print("\n\n\nLESSON 5")
print("Basic operators\n")
let months = 9
var days = 3
var i = 0
while i < months {
  if(i % 2 == 0){
    days += 30
  } else{
    days += 31
  }
  i += 1
}
var seconds = 0
seconds = days * 24 * 60 * 60
print(seconds)
print(days)
var quarter = 0
if( months <= 3){
  quarter = 1
  print("You were born in \(quarter) quarter")
} else if( months <= 6){
  quarter = 2
  print("You were born in \(quarter) quarter")
} else if( months <= 9){
  quarter = 3
  print("You were born in \(quarter) quarter")
} else if( months <= 12){
  quarter = 4
  print("You were born in \(quarter) quarter")
}
var color : String = "blue"
print("Enter a number (Y) : ", terminator: "")
if let inputY = readLine() {
  if let Y = Int(inputY) {
    print("Enter a number (X) : ", terminator: "")
    if let inputX = readLine() {
      if let X = Int(inputX) {
        if X % 2 == Y % 2 {
          color = "black"
        } else{
          color = "white"
        }
    }
print(color)
      }
    }
  }

if color.isEmpty {
  print("bad")
} else{
  print("good")
}

print("\n\n\nLESSON 6")
print("String and Characters\n")
var a = 12
var b = 13
var c = 14
var d1 = "15"
var e1 = "16d"
var d = Int(d1) ?? 0
var e = Int(e1) ?? 0
var sum = a + b + c + d + e

print ("\(a) + \(b) + \(c) + \(d) + \(e) = \(sum)")

var final = String(a) + " + " + String(b) + " + " + String(c) + " + " + String(d) + " + " + String(e) + " = " + String(sum)

var char = "x"
var counter = 0
for char in "abcdefghjiklmnopqrstuvwxyz"{
    if char == "v"{
        print(counter)
    }
    counter += 1
}

print("\n\n\nLESSON 7")
print("Collection types\n")
var money = [100, 1, 5, 20, 1, 50, 1, 1, 20, 1]
var sum = 0
var i = 0
while i < money.count {
  sum += money[i]
  i += 1
}
for value in money{
    sum += value
}
print(sum)
money.sort()



print ("\n\n\n\n HOMEWORK")
let months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
for n in months{
    print(n)
}
let monthsName = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
var counter = 0
while counter < months.count{
    print ("Name of the month: \(monthsName[counter]) and the days in this month: \(months[counter])")
    counter += 1
}
counter -= 1
while counter >= 0 {
    print ("Name of the month: \(monthsName[counter]) and the days in this month: \(months[counter])")
    counter -= 1
}

var monthDay = [(month: String, day: Int)] ()

for i in 0..<months.count {
    let tuples = (month: monthsName[i], day: months[i])
    monthDay.append(tuples)
}
print ("\n\n\n")
print(monthDay)
print ("\n\n\n")


counter = 0
while counter < months.count{
    print ("Name of the month: \(monthDay[counter])")
    counter += 1
}


let dob = (month: 10, day: 3)
var days = 0
for j in 0 ..< dob.month - 1 {
    days += months[j]
}

days += dob.day
print ("\n\n\n")
print(days)
print ("\n\n\n")
let optionalarray : [Int?] = [12, 13, Int("1"), 14, 16, nil, 15]
var summ = 0
for value in optionalarray {
    if let value = value{
        summ += value
    }
}
print(summ)
let alphabet = "abcdefghijklmnopqrstuvwxyz"
var revalphabet = [String]()
var n = alphabet.count - 1
for Character in alphabet {
    revalphabet.insert(String(Character), at: 0)
}


print(revalphabet)

print("\n\n\nLESSON 8")
print("Dictionary\n")

let dict : [String : String] =  ["car" : "Lexus", "man" : "Akrom"]
let dict2 : Dictionary<Int, String> = [0 : "zero", 1 : "one"]

dict["car"]
dict2[0]

//HOMEWORK

var student = ["Akrom Kassymov" : 5, "Maksat Sauytbek" : 4, "Erkebulan Kenzhebek" : 3]
student["Akrom Kassymov"] = 6
student.updateValue( 5, forKey: "Erkebulan Kenzhebek")
student
student["Bekzhan Abdullayev"] = 6
student["Abylay Sydykov"] = 6
student["Maksat Sauytbek"] = nil
student.removeValue(forKey: "Erkebulan Kenzhebek")
student
var counter = 0
var sum = 0
for (_, value) in student{
    sum += value
    counter += 1
}
print ("Summ of the marks of the students is \(sum), and average value is \(sum/counter)")


var months = ["January" : 31, "February" : 28, "March" : 31, "April" : 30, "May" : 31, "June" : 30, "July" : 31, "August" : 31, "September" : 30, "October" : 31, "November" : 30, "December" : 31]
for (month, day) in months{
    print("The month is: \(month) and the number of days in it: \(day)")
}
for key in months.keys {
    print("The month is: \(key) and the number of days in it: \(months[key]!)")
}


var positions = ["a1" : true]
positions.removeAll()
positions
var letters = "abcdefgh"
var keys : String
var n = 1
for char in letters {
    for numbers in 1..<9 {
        keys = "\(char)\(numbers) "
        if (numbers % 2 == n % 2){
            positions[keys] = false
        } else {
            positions[keys] = true
        }
    }
    n += 1
}
positions
 
print("\n\n\nLESSON 9")
print("Switch operator\n")
var text = "Lorem ipsum dolor 2 sit amet, consectetuer adipiscing elit. Aenean commo 3 do ligula eget dolor. Aenean massa. Cum soci 4 is natoque penatibus et magnis dis part 5 urient montes, nascetur 6 ridiculus mus. Donec qu 1"
var numbers = 0
var glas = 0
var sogl = 0
var znaki = 0
for value in text{
    switch value{
        case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" : numbers += 1
        case "a", "i", "e", "o" : glas += 1
        case ",", ".", "?", "!", ":" : znaki += 1
        default : sogl += 1
    }
}

var age = 20

switch age {
case 0...5 : print("child")
case 5...10 : print("pupil")
case 11...16 : print("teenager")
case 17...26 : print("adolescent")
case 27...55 : print("adult")
case 60...120 : print("old man")
default : print("who are you")
}

let name = "Akrom"
let surname = "Kassymov"
let father = "Akbarovich"
var tuple = (name, surname, father)

switch tuple {
case _ where name.hasPrefix("A") || name.hasPrefix("O") : print ("Hello, \(name)")
case _ where father.hasPrefix("V") || father.hasPrefix("d") : print ("Hello, \(name) \(father)")
case _ where surname.hasPrefix("E") || surname.hasPrefix("Z") : print ("Hello, \(name) \(surname)")
default : print("Hello \(surname) \(name) \(father)")
}

print("\n\n\nLESSON 10")
print("Fuctions\n")
func calculateMoney (_ wallet : [Int]) -> Int {
    var sum = 0
    for value in wallet{
        sum += value
    }
    return sum
}

var wallet = [100, 1, 20, 5, 10, 1, 1, 5, 1, 1]
var money = calculateMoney(wallet)


print("\n\n HomeWork \n\n")
func heart () -> String {
    let heart = "\u{1F5A4}"
    return heart
}
heart()

func I () -> String {
    let I = "I"
    return I
}

func you () -> String {
    let you = "you"
    return you
}

print (I() + " " + heart() + " " + you())


func table (vertical number : Int, horizontal char : Character) -> String?{
    var vertical = 0
    switch char {
    case "a","c","e","g" : vertical = 1
    case "b","d","f","h" : vertical = 2
    default: break
    }
    if (number % 2 == vertical % 2){
        return "black"
    } else {
        return "white"
    }
}

var number = 8
var char : Character = "g"
var position = table(vertical: number, horizontal: char)
print(position!)


var array = [100, 1, 20, 5, 10, 1, 1, 5, 1, 1]
func reverse (toReverse array : [Int]) -> [Int] {
    var revarr = array
    var counter = 0
    let n = revarr.count - 1
    for value in array{
        revarr[n - counter] = value
        counter += 1
    }
    return revarr
}

var reversed = reverse(toReverse: array)
print(reversed)



func inoutreverse (reversable array : inout [Int]) {
    var revarr = array
    var counter = 0
    let n = revarr.count - 1
    for value in array{
        revarr[n - counter] = value
        counter += 1
    }
    array = revarr
}
inoutreverse(reversable: &array)
print(array)


func changeText (text paragraph : inout String) {
    var i = 0
    for value in paragraph {
        switch value {
        case ",", ".", "!", "?": print(" ")
        case "a": print("A")
        case "e": print("E")
        case "o": print("O")
        case "i": print("I")
        default: print("error")
        }
        i += 1
    }
}

var line = "!a.e,i?obng"
changeText(text: &line)
print(line)
